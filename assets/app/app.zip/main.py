import flet as ft
import datetime

def main(page: ft.Page):
    date = datetime.date(2025, 7, 12)
    counter = ft.Text(date, size=50, data=0)



    page.add(
        ft.SafeArea(
            ft.Container(
                counter,
                alignment=ft.alignment.center,
            ),
            expand=True,
        )
    )


ft.app(main)
